# authordown 0.1.0

- Initial CRAN-ready release with templates, validation, and section generators.
- Added offline-safe workflow vignette and pkgdown config.

# authordown 0.1.0

- Initial CRAN-ready release with template support, validation, and title page/section generators.

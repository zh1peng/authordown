library(testthat)
library(authordown)

test_check("authordown")

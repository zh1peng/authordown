## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(authordown)

csv_path <- system.file("extdata", "authordown_template.csv", package = "authordown")
authors <- authordown_read_local(csv_path)

## -----------------------------------------------------------------------------
authordown_template("authors.csv")

## -----------------------------------------------------------------------------
title_page <- generate_title_page(
  data = authors,
  title = "Example Paper",
  style = "default",
  show_degree = TRUE
)
cat(title_page)

## -----------------------------------------------------------------------------
ack <- generate_acknowledgement(authors, style = "paragraph")
coi <- generate_conflict(authors, style = "paragraph")
contrib <- generate_contribution(authors, style = "bullets")

cat(ack)
cat("\n\n")
cat(coi)
cat("\n\n")
cat(contrib)

## -----------------------------------------------------------------------------
xlsx_path <- system.file("extdata", "authordown_template.xlsx", package = "authordown")
authors_xlsx <- authordown_read_local(xlsx_path)

## ----eval=FALSE---------------------------------------------------------------
#  # Google Sheets
#  sheet_url <- "https://docs.google.com/spreadsheets/d/..."
#  authors <- authordown_read_google_sheet(sheet_url)
#  
#  # Tencent table
#  qq_url <- "https://docs.qq.com/sheet/..."
#  authors <- authordown_read_tencent(qq_url)


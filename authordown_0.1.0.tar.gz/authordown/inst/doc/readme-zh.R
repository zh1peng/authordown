## ----echo=FALSE, results='asis'-----------------------------------------------
input_dir <- dirname(knitr::current_input())
path <- file.path(input_dir, "README.zh.md")
lines <- readLines(path, warn = FALSE)
lines <- lines[!grepl("R-CMD-check", lines)]
cat(lines, sep = "\n")

